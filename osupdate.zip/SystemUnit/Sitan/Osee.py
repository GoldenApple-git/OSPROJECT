class Osee:
    def __init__(self,value):
        self.value = value
    def aff(self):
        return self.value